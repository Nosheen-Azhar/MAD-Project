import {getAuth} from 'firebase/auth';
import {initializeApp} from 'firebase/app';


// Import the functions you need from the SDKs you need
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC3kpEphx45g0TdhhqPaq6qX6bitGStRg4",
  authDomain: "nutri-ccff0.firebaseapp.com",
  projectId: "nutri-ccff0",
  storageBucket: "nutri-ccff0.appspot.com",
  messagingSenderId: "267606637656",
  appId: "1:267606637656:web:6e964fa7eb30d41e4a1e2d"
};

// Initialize Firebase

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
export {app, auth};