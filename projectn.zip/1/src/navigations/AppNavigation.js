import React from 'react'
import { createStackNavigator } from '@react-navigation/stack'
import { NavigationContainer } from '@react-navigation/native'
import { createDrawerNavigator } from '@react-navigation/drawer'
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'
import NutriCraftPage from '../screens/NutriCraftPage/NutriCraftPage'
import ProfileManagementScreen from '../screens/ProfileManagementScreen/ProfileManagementScreen'
import IngredientSubstitutes from '../screens/IngredientSubstitutes/IngredientSubstitutes'
import IngredientInformation from '../screens/IngredientInformation/IngredientInformation'
import IngredientAmount from '../screens/IngredientAmount/IngredientAmount'
import HomeScreen from '../screens/Home/HomeScreen';
import FrontScreen from '../screens/FrontScreen/FrontScreen';
import CategoriesScreen from '../screens/Categories/CategoriesScreen';
import RecipeScreen from '../screens/Recipe/RecipeScreen';
import RecipesListScreen from '../screens/RecipesList/RecipesListScreen';
import DrawerContainer from '../screens/DrawerContainer/DrawerContainer';
import IngredientScreen from '../screens/Ingredient/IngredientScreen';
import SearchScreen from '../screens/Search/SearchScreen';
import IngredientsDetailsScreen from '../screens/IngredientsDetails/IngredientsDetailsScreen';
import LoginScreen from '../screens/Login/LoginScreen'
import Signup from '../screens/Signup1/Signup'
import RecipeAdjustmentScreen from '../screens/RecipeAdjustmentScreen/RecipeAdjustementScreen'
// import NutritionalEducation from '../screens/NutritionalEducation/NutritionalEducation'
import ForgotPasswordScreen from '../screens/ForgotPasswordScreen/ForgotPasswordScreen'
// import HealthMetricsTracking from '../screens/HealthMetricsTracking/HealthMetricsTracking'
import GroceryList from '../screens/GroceryList/GroceryList'
import MealPlanAccessScreen from '../screens/MealPlanAccessScreen/MealPlanAccessScreen'
import NutritionScreen from '../screens/NutritionScreen/NutritionScreen'
import { FontAwesome, Ionicons, MaterialIcons } from '@expo/vector-icons';

const Tab = createBottomTabNavigator();
const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

function MainNavigator() {
  return (
    <Stack.Navigator
      screenOptions={{
        headerTitleStyle: {
          fontWeight: 'bold',
          textAlign: 'center',
          alignSelf: 'center',
          flex: 1,
        }
      }}
    >
      <Stack.Screen name='NutriCraftPage' component={NutriCraftPage} />
      <Stack.Screen name='Signup' component={Signup} />
      <Stack.Screen name='LoginScreen' component={LoginScreen} />
      <Stack.Screen name='ForgotPasswordScreen' component={ForgotPasswordScreen} />
      <Stack.Screen name='FrontScreen' component={FrontScreen} />
      <Stack.Screen name='Home' component={HomeScreen} />
      <Stack.Screen name='Categories' component={CategoriesScreen} />
      <Stack.Screen name='Recipe' component={RecipeScreen} />
      <Stack.Screen name='RecipesList' component={RecipesListScreen} />
      <Stack.Screen name='Ingredient' component={IngredientScreen} />
      <Stack.Screen name='Search' component={SearchScreen} />
      <Stack.Screen name='IngredientsDetails' component={IngredientsDetailsScreen} />
      <Stack.Screen name='ProfileManagementScreen' component={ProfileManagementScreen} />
      <Stack.Screen name='IngredientSubstitutes' component={IngredientSubstitutes} />
      <Stack.Screen name='RecipeAdjustmentScreen' component={RecipeAdjustmentScreen} />
      {/* <Stack.Screen name='NutritionalEducation' component={NutritionalEducation} /> */}
      <Stack.Screen name='IngredientInformation' component={IngredientInformation} />
      <Stack.Screen name='IngredientAmount' component={IngredientAmount} />
      {/* <Stack.Screen name='HealthMetricsTracking' component={HealthMetricsTracking} /> */}
      <Stack.Screen name='GroceryList' component={GroceryList} />
      <Stack.Screen name='MealPlanAccessScreen' component={MealPlanAccessScreen} options={{headerShown:false}} />
      <Stack.Screen name='NutritionScreen' component={NutritionScreen} />
      
    </Stack.Navigator>
  )
}

function MyTabs() {
  return (
    <Tab.Navigator
      tabBarOptions={{
        activeTintColor: '#8dc63f',
      }}
    >
      <Tab.Screen
        name="Home"
        component={MainNavigator}
        options={{
          tabBarIcon: ({ color, size }) => (
            <FontAwesome name="home" size={size} color={color} />

          ),
            headerShown: false
        }}
      />
    <Tab.Screen
        name="Search"
        component={SearchScreen}
        options={{
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="search" size={size} color={color} />
          ),
        }}
      />
      <Tab.Screen
        name="MealPlanAccess"
        component={MealPlanAccessScreen}
        options={{
          tabBarIcon: ({ color, size }) => (
            <MaterialIcons name="calendar-today" size={size} color={color} />
          ),
          headerShown: false
        }}
      />
      
    </Tab.Navigator>
  );
}


function DrawerStack() {
  return (
    <Drawer.Navigator
      drawerPosition='left'
      initialRouteName='Main'
      drawerStyle={{
        width: 250
      }}
      screenOptions={{ headerShown: false }}
      drawerContent={({ navigation }) => <DrawerContainer navigation={navigation} />}

    >
      {/* <Drawer.Screen name='Main' component={MainNavigator} /> */}
      <Drawer.Screen name='MyTab' component={MyTabs} />
      

    </Drawer.Navigator>
  )
}

export default function AppContainer() {
  return (
    <NavigationContainer>
      <DrawerStack />
    </NavigationContainer>
  )
}

console.disableYellowBox = false;