import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ForgotPasswordScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');

  const handleForgotPassword = async () => {
    try {
      // Validation checks
      if (!email) {
        Alert.alert('Error', 'Email is required.');
        return;
      }

      // Generate a random reset token (for simplicity, in a real app, use a more secure method)
      const resetToken = Math.random().toString(36).substring(7);
      
      // Store the reset token in AsyncStorage
      await AsyncStorage.setItem('resetToken', resetToken);

      // Display success message and navigate to reset password screen
      Alert.alert('Reset Token Sent', 'A reset token has been sent to your email address.');
      navigation.replace('ResetPassword', { resetToken });
    } catch (error) {
      console.error('Error during password reset:', error);
      Alert.alert('Password Reset Failed', 'An error occurred during password reset. Please try again.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Forgot Password</Text>

      {/* Email Input */}
      <TextInput
        style={styles.input}
        placeholder="Email"
        value={email}
        onChangeText={(text) => setEmail(text)}
        autoCapitalize="none"
        keyboardType="email-address"
      />

      {/* Reset Password Button */}
      <TouchableOpacity style={styles.button} onPress={handleForgotPassword}>
        <Text style={styles.buttonText}>Reset Password</Text>
      </TouchableOpacity>

      {/* Back to Login Link */}
      <TouchableOpacity onPress={() => navigation.replace('LoginScreen')}>
        <Text style={styles.link}>Back to Login</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5F0FF',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#6A0572',
    marginBottom: 20,
  },
  input: {
    height: 40,
    width: '100%',
    borderColor: '#6A0572',
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 15,
    padding: 10,
  },
  button: {
    backgroundColor: '#D4A5A5',
    padding: 10,
    borderRadius: 8,
    width: '100%',
    alignItems: 'center',
    marginBottom: 15,
  },
  buttonText: {
    color: '#6A0572',
    fontSize: 16,
    fontWeight: 'bold',
  },
  link: {
    color: '#6A0572',
    textDecorationLine: 'underline',
    marginTop: 10,
  },
});

export default ForgotPasswordScreen;
