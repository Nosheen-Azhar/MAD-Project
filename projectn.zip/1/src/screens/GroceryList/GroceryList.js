// GroceryListScreen.js
import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Modal,
  Pressable,
  StyleSheet,
} from 'react-native';

const GroceryList = () => {
  const [item, setItem] = useState('');
  const [groceryList, setGroceryList] = useState([]);
  const [selectedItem, setSelectedItem] = useState(null);
  const [isEditModalVisible, setIsEditModalVisible] = useState(false);

  const itemTextInputRef = useRef(null);

  const addItem = () => {
    if (item.trim() !== '') {
      setGroceryList([...groceryList, { id: Date.now().toString(), name: item, purchased: false }]);
      setItem('');
    }
  };

  const removeItem = (itemId) => {
    const updatedList = groceryList.filter((item) => item.id !== itemId);
    setGroceryList(updatedList);
  };

  const editItem = () => {
    const updatedList = groceryList.map((groceryItem) => {
      if (groceryItem.id === selectedItem.id) {
        return { ...groceryItem, name: item };
      }
      return groceryItem;
    });
    setGroceryList(updatedList);
    setItem('');
    setSelectedItem(null);
    setIsEditModalVisible(false);
  };

  const clearAll = () => {
    setGroceryList([]);
  };

  const toggleEditModal = (item) => {
    setSelectedItem(item);
    setItem(item.name);
    setIsEditModalVisible(true);
  };

  const togglePurchaseStatus = (itemId) => {
    const updatedList = groceryList.map((groceryItem) => {
      if (groceryItem.id === itemId) {
        return { ...groceryItem, purchased: !groceryItem.purchased };
      }
      return groceryItem;
    });
    setGroceryList(updatedList);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Nutri Craft Grocery List</Text>
      <TextInput
        style={styles.input}
        placeholder="Add item to your grocery list"
        value={item}
        onChangeText={(text) => setItem(text)}
        ref={itemTextInputRef}
      />
      <TouchableOpacity style={styles.addButton} onPress={addItem}>
        <Text style={styles.buttonText}>Add</Text>
      </TouchableOpacity>
      <FlatList
        style={styles.list}
        data={groceryList}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <View style={styles.listItemContainer}>
            <TouchableOpacity
              onPress={() => togglePurchaseStatus(item.id)}
              style={item.purchased ? styles.purchasedItem : null}
            >
              <Text style={styles.listItem}>{item.name}</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => toggleEditModal(item)}>
              <Text style={styles.editButton}>Edit</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => removeItem(item.id)}>
              <Text style={styles.removeButton}>Remove</Text>
            </TouchableOpacity>
          </View>
        )}
      />
      {groceryList.length > 0 && (
        <TouchableOpacity style={styles.clearButton} onPress={clearAll}>
          <Text style={styles.buttonText}>Clear All</Text>
        </TouchableOpacity>
      )}
      <Modal animationType="slide" transparent={true} visible={isEditModalVisible}>
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Edit Item</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Edit item"
              value={item}
              onChangeText={(text) => setItem(text)}
            />
            <TouchableOpacity style={styles.modalButton} onPress={editItem}>
              <Text style={styles.buttonText}>Save</Text>
            </TouchableOpacity>
            <Pressable
              style={styles.modalButton}
              onPress={() => {
                setItem('');
                setIsEditModalVisible(false);
              }}
            >
              <Text style={styles.buttonText}>Cancel</Text>
            </Pressable>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#00A86B',
    marginBottom: 20,
  },
  input: {
    height: 40,
    borderColor: '#00A86B',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  addButton: {
    backgroundColor: '#00A86B',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  list: {
    flex: 1,
  },
  listItemContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  listItem: {
    fontSize: 16,
  },
  purchasedItem: {
    textDecorationLine: 'line-through',
  },
  editButton: {
    color: '#00A86B',
    fontSize: 16,
    marginLeft: 10,
  },
  removeButton: {
    color: 'red',
    fontSize: 16,
    marginLeft: 10,
  },
  clearButton: {
    backgroundColor: 'red',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginTop: 10,
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    padding: 20,
    borderRadius: 10,
    width: '80%',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#00A86B',
    marginBottom: 10,
  },
  modalInput: {
    height: 40,
    borderColor: '#00A86B',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 10,
    paddingHorizontal: 10,
  },
  modalButton: {
    backgroundColor: '#00A86B',
    padding: 10,
    borderRadius: 5,
    alignItems: 'center',
    marginBottom: 10,
  },
});

export default GroceryList;
