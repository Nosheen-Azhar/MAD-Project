import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

const API_KEY = '82b165711705467dacd35f4113e0c74d';
const API_URL = 'https://api.spoonacular.com/food/ingredients';

const IngredientAmount = () => {
  const [query, setQuery] = useState('');
  const [nutrient, setNutrient] = useState('');
  const [target, setTarget] = useState('');
  const [unit, setUnit] = useState('');
  const [result, setResult] = useState(null);

  const handleSearch = async () => {
    try {
      const response = await fetch(
        `${API_URL}/search?query=${query}&number=1&apiKey=${API_KEY}`
      );
      const data = await response.json();

      if (data.results.length > 0) {
        const ingredientId = data.results[0].id;
        const amountResponse = await fetch(
          `${API_URL}/${ingredientId}/amount?nutrient=${nutrient}&target=${target}&unit=${unit}&apiKey=${API_KEY}`
        );
        const amountData = await amountResponse.json();
        setResult(amountData);
      } else {
        setResult(null);
      }
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Ingredient Amount Calculation</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter ingredient"
        value={query}
        onChangeText={(text) => setQuery(text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Enter nutrient"
        value={nutrient}
        onChangeText={(text) => setNutrient(text)}
      />
      <TextInput
        style={styles.input}
        placeholder="Enter target"
        value={target}
        onChangeText={(text) => setTarget(text)}
        keyboardType="numeric"
      />
      <TextInput
        style={styles.input}
        placeholder="Enter unit"
        value={unit}
        onChangeText={(text) => setUnit(text)}
      />
      <Button style={styles.button1} title="Calculate Amount" onPress={handleSearch} />

      {result && (
        <View style={styles.resultContainer}>
          <Text style={styles.resultText}>
            You need {result.amount} {result.unit} of {query} to reach {target} {unit} of {nutrient}.
          </Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#f7f7f7',
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
    color: '#330',
  },
  input: {
    height: 40,
    borderColor: '#8dc63f',
    borderWidth: 1,
    marginBottom: 16,
    paddingLeft: 8,
    borderRadius: 8,
    backgroundColor: '#fff',
  },
  

  resultContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  resultText: {
    fontSize: 16,
    marginTop: 10,
    color: '#8dc63f',
  },
});

export default IngredientAmount;
