import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Image,
  TextInput,
} from 'react-native';
import { createStackNavigator } from '@react-navigation/stack';

const Stack = createStackNavigator();

const MealDetailsScreen = ({ route, navigation }) => {
  const { id, title, description } = route.params;
  const [isFavorite, setIsFavorite] = useState(false);
  const [rating, setRating] = useState(0);

  const toggleFavorite = () => {
    setIsFavorite(!isFavorite);
  };

  const handleRating = (newRating) => {
    setRating(newRating);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title}</Text>
      <Text style={styles.mealPlanDescription}>{description}</Text>
      <View style={styles.ratingContainer}>
        <Text style={styles.ratingText}>Rate this meal plan:</Text>
        {[1, 2, 3, 4, 5].map((star) => (
          <TouchableOpacity
            key={star}
            onPress={() => handleRating(star)}
            style={styles.starContainer}>
            <Image
              source={
                star <= rating
                  ? require('../../../assets/icons/star_filled.jpeg') // Replace with your star icon
                  : require('../../../assets/icons/star_outline.jpeg') // Replace with your star outline icon
              }
              style={styles.starIcon}
            />
          </TouchableOpacity>
        ))}
      </View>
      <TouchableOpacity onPress={toggleFavorite} style={styles.favoriteButton}>
        <Text style={styles.favoriteButtonText}>
          {isFavorite ? 'Remove from Favorites' : 'Add to Favorites'}
        </Text>
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => navigation.navigate('Ingredients', { id, title })}
        style={styles.ingredientsButton}>
        <Text style={styles.ingredientsButtonText}>View Ingredients</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
        <Text style={styles.backButtonText}>Go Back</Text>
      </TouchableOpacity>
    </View>
  );
};

const IngredientsScreen = ({ route }) => {
  const { id, title } = route.params;

  // Replace with real ingredients for each meal plan
  const ingredientsMap = {
    Breakfast: [
      '2 eggs',
      '1 avocado',
      '1 tomato',
      'Salt and pepper to taste',
    ],
    Lunch: [
      'Grilled chicken breast',
      'Quinoa',
      'Mixed vegetables',
      'Olive oil',
    ],
    Dinner: [
      'Salmon fillet',
      'Sweet potatoes',
      'Broccoli',
      'Lemon',
      'Garlic',
    ],
    Snacks: [
      'Greek yogurt',
      'Berries',
      'Almonds',
    ],
    Smoothies: [
      'Banana',
      'Spinach',
      'Greek yogurt',
      'Almond milk',
    ],
    Vegetarian: [
      'Chickpeas',
      'Quinoa',
      'Bell peppers',
      'Feta cheese',
      'Olive oil',
    ],
    LowCarb: [
      'Cauliflower rice',
      'Chicken thighs',
      'Zucchini',
      'Cherry tomatoes',
    ],
    HighProtein: [
      'Lean beef',
      'Brown rice',
      'Eggs',
      'Asparagus',
    ],
    Desserts: [
      'Oat flour',
      'Bananas',
      'Dark chocolate chips',
      'Honey',
    ],
    Mediterranean: [
      'Olive oil',
      'Tomatoes',
      'Cucumbers',
      'Feta cheese',
    ],
    GlutenFree: [
      'Quinoa',
      'Chicken breast',
      'Broccoli',
      'Carrots',
    ],
    Vegan: [
      'Lentils',
      'Brown rice',
      'Kale',
      'Avocado',
    ],
    // Add more ingredients as needed
  };

  const ingredients = ingredientsMap[title] || [];

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{title} Ingredients</Text>
      <FlatList
        data={ingredients}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <View style={styles.ingredientsItem}>
            <Image
              source={require('../../../assets/icons/ingredient_icon.jpeg')} // Replace with your ingredient icon
              style={styles.ingredientsIcon}
            />
            <Text style={styles.ingredientsText}>{item}</Text>
          </View>
        )}
      />
    </View>
  );
};

const MealPlanAccessScreen = ({ navigation }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const mealPlans = [
    { id: '1', title: 'Breakfast', description: 'Healthy breakfast plan' },
    { id: '2', title: 'Lunch', description: 'Nutritious lunch plan' },
    { id: '3', title: 'Dinner', description: 'Balanced dinner plan' },
    { id: '4', title: 'Snacks', description: 'Quick and healthy snacks' },
    { id: '5', title: 'Smoothies', description: 'Refreshing smoothie recipes' },
    { id: '6', title: 'Vegetarian', description: 'Vegetarian meal ideas' },
    { id: '7', title: 'Low Carb', description: 'Low-carb meal options' },
    { id: '8', title: 'High Protein', description: 'High-protein meal choices' },
    { id: '9', title: 'Desserts', description: 'Sweet and healthy desserts' },
    { id: '10', title: 'Mediterranean', description: 'Mediterranean diet-inspired meals' },
    { id: '11', title: 'Gluten-Free', description: 'Gluten-free meal options' },
    { id: '12', title: 'Vegan', description: 'Plant-based vegan meals' },
    { id: '13', title: 'Keto', description: 'Keto-friendly meal plans' },
    { id: '14', title: 'Paleo', description: 'Paleolithic diet meals' },
    { id: '15', title: 'Whole30', description: 'Whole30-compliant meal ideas' },
    // Add more meal plans as needed
  ];

  const filteredMealPlans = useMemo(
    () =>
      mealPlans.filter(
        (plan) =>
          plan.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          plan.description.toLowerCase().includes(searchQuery.toLowerCase())
      ),
    [mealPlans, searchQuery]
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Nutri Craft Meal Plans</Text>
      <TextInput
        style={styles.searchInput}
        placeholder="Search Meal Plans"
        onChangeText={(text) => setSearchQuery(text)}
        value={searchQuery}
      />
      <FlatList
        data={filteredMealPlans}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.mealPlanContainer}
            onPress={() =>
              navigation.navigate('MealDetails', {
                id: item.id,
                title: item.title,
                description: item.description,
              })
            }>
            <Image
              source={require('../../../assets/icons/MP.png')} // Replace with your meal plan icon
              style={styles.mealIcon}
            />
            <View>
              <Text style={styles.mealPlanTitle}>{item.title}</Text>
              <Text style={styles.mealPlanDescription}>{item.description}</Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
};

const MealPlanStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen name="MealPlans" component={MealPlanAccessScreen} />
      <Stack.Screen name="MealDetails" component={MealDetailsScreen} />
      <Stack.Screen name="Ingredients" component={IngredientsScreen} />
    </Stack.Navigator>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#FFFFFF', // White background
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#8dc63f', // Green color
    marginBottom: 16,
  },
  mealPlanContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#e1e3e5', // Light green background
    padding: 16,
    marginBottom: 16,
    borderRadius: 8,
   
  },
  mealIcon: {
    width: 50,
    height: 50,
    marginRight: 16,
  },
  mealPlanTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#8dc63f', // Green color
  },
  mealPlanDescription: {
    fontSize: 16,
    color: '#333333', // Dark gray color
  },
  favoriteButton: {
    padding: 10,
    borderRadius: 8,
    marginTop: 16,
    backgroundColor: '#8dc63f',
  },
  favoriteButtonText: {
    color: '#FFFFFF',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  ingredientsButton: {
    backgroundColor: '#8dc63f', // Yellow for ingredients button
    padding: 10,
    borderRadius: 8,
    marginTop: 16,
  },
  ingredientsButtonText: {
    color: '#FFFFFF',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  backButton: {
    marginTop: 16,
  },
  backButtonText: {
    color: '#8dc63f',
    textAlign: 'center',
    fontSize: 16,
  },
  ingredientsItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#e1e3e5', // Light green background for ingredients
    padding: 16,
    marginBottom: 8,
    borderRadius: 8,
  },
  ingredientsIcon: {
    width: 30,
    height: 30,
    marginRight: 8,
  },
  ingredientsText: {
    fontSize: 16,
    color: '#333333',
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 16,
  },
  ratingText: {
    fontSize: 16,
    marginRight: 8,
    color: '#333333',
  },
  starContainer: {
    padding: 8,
  },
  starIcon: {
    width: 20,
    height: 20,
  },
  searchInput: {
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 8,
    marginBottom: 16,
    paddingLeft: 8,
  },
});

export default MealPlanStack;
