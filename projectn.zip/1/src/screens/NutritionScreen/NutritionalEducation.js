// NutritionalEducationScreen.js
import React, { useState, useEffect } from "react";
import { View, Text, ScrollView, StyleSheet } from "react-native";

const NutritionalEducation = () => {
  const [articles, setArticles] = useState([]);
  const [blogs, setBlogs] = useState([]);
  const [inspirations, setInspirations] = useState([]);
  const [challenges, setChallenges] = useState([]);
  const [macroNutrients, setMacroNutrients] = useState([]);
  const [microNutrients, setMicroNutrients] = useState([]);
  const [vitamins, setVitamins] = useState([]);

  useEffect(() => {
    // Fetch articles
    // Replace 'API_URL/articles' with your actual API endpoint for articles
    fetch('API_URL/articles')
      .then(response => response.json())
      .then(data => setArticles(data));

    // Fetch blogs
    // Replace 'API_URL/blogs' with your actual API endpoint for blogs
    fetch('API_URL/blogs')
      .then(response => response.json())
      .then(data => setBlogs(data));

    // Fetch inspirations
    // Replace 'API_URL/inspirations' with your actual API endpoint for inspirations
    fetch('API_URL/inspirations')
      .then(response => response.json())
      .then(data => setInspirations(data));

    // Fetch challenges
    // Replace 'API_URL/challenges' with your actual API endpoint for challenges
    fetch('API_URL/challenges')
      .then(response => response.json())
      .then(data => setChallenges(data));

    // Fetch macro nutrients
    // Replace 'API_URL/macro-nutrients' with your actual API endpoint for macro nutrients
    fetch('API_URL/macro-nutrients')
      .then(response => response.json())
      .then(data => setMacroNutrients(data));

    // Fetch micro nutrients
    // Replace 'API_URL/micro-nutrients' with your actual API endpoint for micro nutrients
    fetch('API_URL/micro-nutrients')
      .then(response => response.json())
      .then(data => setMicroNutrients(data));

    // Fetch vitamins
    // Replace 'API_URL/vitamins' with your actual API endpoint for vitamins
    fetch('API_URL/vitamins')
      .then(response => response.json())
      .then(data => setVitamins(data));
  }, []);

  return (
    <ScrollView style={styles.container}>
      <View>
        <Text style={styles.sectionTitle}>Articles</Text>
        {/* Display articles here */}
        {articles.map((article, index) => (
          <Text key={index}>{article.title}</Text>
        ))}
      </View>

      <View>
        <Text style={styles.sectionTitle}>Blogs</Text>
        {/* Display blogs here */}
        {blogs.map((blog, index) => (
          <Text key={index}>{blog.title}</Text>
        ))}
      </View>

      <View>
        <Text style={styles.sectionTitle}>Inspirations</Text>
        {/* Display inspirations here */}
        {inspirations.map((inspiration, index) => (
          <Text key={index}>{inspiration.title}</Text>
        ))}
      </View>

      <View>
        <Text style={styles.sectionTitle}>Challenges</Text>
        {/* Display challenges here */}
        {challenges.map((challenge, index) => (
          <Text key={index}>{challenge.title}</Text>
        ))}
      </View>

      <View>
        <Text style={styles.sectionTitle}>Nutritional Information</Text>
        <Text style={styles.subTitle}>Macro Nutrients</Text>
        {/* Display macro nutrients information here */}
        {macroNutrients.map((macro, index) => (
          <Text key={index}>{macro.name}: {macro.value}</Text>
        ))}

        <Text style={styles.subTitle}>Micro Nutrients</Text>
        {/* Display micro nutrients information here */}
        {microNutrients.map((micro, index) => (
          <Text key={index}>{micro.name}: {micro.value}</Text>
        ))}

        <Text style={styles.subTitle}>Vitamins</Text>
        {/* Display vitamins information here */}
        {vitamins.map((vitamin, index) => (
          <Text key={index}>{vitamin.name}: {vitamin.value}</Text>
        ))}
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
  },
  subTitle: {
    fontSize: 20,
    fontWeight: "bold",
    marginBottom: 5,
  },
});

export default NutritionalEducation;
