import { useState } from 'react';
import { View, Text, TextInput, StyleSheet, Button, Image,ImageBackground } from 'react-native';
import { Picker } from '@react-native-picker/picker';
// import LoginScreen from "./LoginScreen";
// import ClientScreen from "./ClientScreen";
import { auth } from "../../../Firebase";

import { createUserWithEmailAndPassword } from 'firebase/auth';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage'; 
const Stack = createStackNavigator();


const Signup = () => {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [age, setAge] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [signupAs, setSignupAs] = useState('Nutritionist'); // Default value
  const navigation = useNavigation(); 

  const handleLoginNavigation = () => {
    navigation.navigate('LoginScreen');
  };

  const handleSignup = async () => {
    // Implement your signup logic here
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;
      console.log("user data,", user);
      navigation.navigate('LoginScreen');
    } catch (error) {
      const errorCode = error.code;
      const errorMessage = error.message;
      console.log('Error Code == ', errorCode);
      console.log('Error Message == ', errorMessage);
    }
  };


  

  return (
    <ImageBackground source={require('../../../assets/icons/SignUp.png')} style={styles.backgroundImage}>
    
    <View style={styles.container}>
      <Text style={styles.title}>Sign Up</Text>

      <Text style={styles.label}>Username </Text>
      <TextInput
        style={styles.input}
        placeholder="Enter username"
        onChangeText={(text) => setUsername(text)}
        value={username}
      />

      <Text style={styles.label}>Email </Text>
      <TextInput
        style={styles.input}
        placeholder="Enter email"
        onChangeText={(text) => setEmail(text)}
        value={email}
      />

      <Text style={styles.label}>Phone Number </Text>
      <TextInput
        style={styles.input}
        placeholder="Enter phone number"
        onChangeText={(text) => setPhoneNumber(text)}
        value={phoneNumber}
      />

      <Text style={styles.label}>Age </Text>
      <TextInput
        style={styles.input}
        placeholder="Enter age"
        onChangeText={(text) => setAge(text)}
        value={age}
      />

      <Text style={styles.label}>Password </Text>
      <TextInput
        style={styles.input}
        placeholder="Enter password"
        onChangeText={(text) => setPassword(text)}
        value={password}
        secureTextEntry={true}
      />

      <Text style={styles.label}>Confirm Password </Text>
      <TextInput
        style={styles.input}
        placeholder="Confirm password"
        onChangeText={(text) => setConfirmPassword(text)}
        value={confirmPassword}
        secureTextEntry={true}
      />

  

      <View style={styles.buttonsContainer}>
        <Button title="Sign Up"  color="#8dc63f" onPress={handleSignup} />
      </View>

      <View style={styles.loginTextContainer}>
        <Text style={styles.loginText}>Already have an account?</Text>
        <Button
          title="Login"
          color="#8dc63f"
          onPress={handleLoginNavigation}
      
        />
      </View>

      <View style={styles.logosContainer}>
        {/* <Image source={require('./assets/fb.jpg')} style={styles.logo} /> */}
        {/* <Image source={require('./assets/google.webp')} style={styles.logo} /> */}
      </View>
    </View>
     </ImageBackground>
  );
};

const App = () => {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="SignUp">
        <Stack.Screen name="SignUp" component={SignUpScreen} options={{ title: 'Sign Up' }} />
        <Stack.Screen name="Login" component={LoginScreen} options={{ title: 'Login' }} />
        <Stack.Screen name="ClientScreen" component={ClientScreen} options={{ title: 'Client' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
};
const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
    resizeMode: 'cover'
  },
  container: {
    padding: 70,
    backgroundColor: 'rgba(0,0,0,0)',
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
    marginTop:30,
  },
  input: {
    height: 40,
    borderColor: 'black',
    borderWidth: 1,
    borderRadius: 4,
    padding: 10,
    marginBottom: 10,
  },
  label: {
    fontSize: 16,
    marginBottom: 1,
  },
  signupAsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  signupAsLabel: {
    fontSize: 16,
    marginRight: 10,
  },
  dropdown: {
    width: 150,
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    borderRadius: 4,
    padding: 10,
  },
  buttonsContainer: {
    marginBottom: 20,
  },
  logosContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 20,
  },
  logo: {
    width: 50,
    height: 50,
  },
   loginTextContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loginText: {
    marginRight: 5,
  },
});

export default Signup;
